//
//  ViewController.swift
//  TableViewCollapse&Expand
//
//  Created by Utkarsh Patel on 26/06/19.
//  Copyright © 2019 Utkarsh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

